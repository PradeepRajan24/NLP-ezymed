<?php

namespace App\Console\Commands;

use DateTime;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class PatientsImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:PATIENTS';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command to import Patients CSV file';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $filename = "data/PATIENTS.csv";
        $table = 'patients';

        if (!Storage::exists($filename)) {
            $this->error("File does not exist.");
            return;
        }
        $data = array_map('str_getcsv', file(Storage::path($filename)));
        $headers = array_shift($data);

        DB::beginTransaction();

        try {
            $i = 1;
            foreach ($data as $row) {
                //type casting
                $row[0] = $row[0] === '' ? null : intval($row[0]);
                $row[1] = $row[1] === '' ? null : intval($row[1]);
                
                $date = $row[3];
                $date_obj = new DateTime($date);
                $row[3] = $date_obj->format('Y-m-d H:i:s');

                $date1 = $row[4];
                $date_obj1 = new DateTime($date1);
                $row[4] = $date_obj1->format('Y-m-d H:i:s');

                $date2 = $row[5];
                $date_obj2 = new DateTime($date2);
                $row[5] = $date_obj2->format('Y-m-d H:i:s');

                $date3 = $row[6];
                $date_obj3 = new DateTime($date3);
                $row[6] = $date_obj3->format('Y-m-d H:i:s');

                $row[7] = $row[7] === '' ? null : intval($row[7]);
              

                $values = array_combine($headers, $row);
                $this->info('Inserting:'.$i++);

                DB::table($table)->insert($values);
            }

            DB::commit();

            $this->info('Data imported successfully.');
        } catch (\Exception $e) {
            DB::rollback();

            $this->error("Error importing data: {$e->getMessage()}");
        }
    }
}
