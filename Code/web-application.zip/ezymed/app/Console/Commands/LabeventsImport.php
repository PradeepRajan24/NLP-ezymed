<?php

namespace App\Console\Commands;

use DateTime;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class LabeventsImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:LABEVENTS';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command to import Lab Events CSV file';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $filename = "data/LABEVENTS.csv";
        $table = 'lab_events';

        if (!Storage::exists($filename)) {
            $this->error("File does not exist.");
            return;
        }
        $data = array_map('str_getcsv', file(Storage::path($filename)));
        $headers = array_shift($data);

        DB::beginTransaction();

        try {
            $i = 1;
            foreach ($data as $row) {
                
                //type casting
                $row[0] = $row[0] === '' ? null : intval($row[0]);
                $row[1] = $row[1] === '' ? null : intval($row[1]);
                $row[2] = $row[2] === '' ? null : intval($row[2]);
                $row[3] = $row[3] === '' ? null : intval($row[3]);
                
                $date_str = $row[4];
                $datetime = new DateTime($date_str);

                $row[4] = $datetime->format('Y-m-d H:i:s');
                $row[6] = $row[6] === '' ? null : (float)$row[6];

                $values = array_combine($headers, $row);
                $this->info('Inserting:'.$i++);

                DB::table($table)->insert($values);
            }

            DB::commit();

            $this->info('Data imported successfully.');
        } catch (\Exception $e) {
            DB::rollback();

            $this->error("Error importing data: {$e->getMessage()}");
        }
    }
}
