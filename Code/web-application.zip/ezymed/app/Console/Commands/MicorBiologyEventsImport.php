<?php

namespace App\Console\Commands;

use DateTime;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class MicorBiologyEventsImport extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:MICROEVENTS';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command to import microbiology events CSV file';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $filename = "data/MICROBIOLOGYEVENTS.csv";
        $table = 'micro_biology_events';

        if (!Storage::exists($filename)) {
            $this->error("File does not exist.");
            return;
        }
        $data = array_map('str_getcsv', file(Storage::path($filename)));
        $headers = array_shift($data);

        DB::beginTransaction();

        try {
            $i = 1;
            foreach ($data as $row) {
                //type casting
                $row[0] = $row[0] === '' ? null : intval($row[0]);
                $row[1] = $row[1] === '' ? null : intval($row[1]);
                $row[2] = $row[2] === '' ? null : intval($row[2]);
                
                $date = $row[3];
                $date_obj = new DateTime($date);
                $row[3] = $date_obj->format('Y-m-d H:i:s');

                $time = $row[4];
                $time_obj = new DateTime($time);
                $row[4] = $time_obj->format('Y-m-d H:i:s');
                
                $row[5] = $row[5] === '' ? null : intval($row[5]);
                $row[7] = $row[7] === '' ? null : intval($row[7]);
                $row[9] = $row[9] === '' ? null : intval($row[9]);
                $row[10] = $row[10] === '' ? null : intval($row[10]);

                $values = array_combine($headers, $row);
                $this->info('Inserting:'.$i++);

                DB::table($table)->insert($values);
            }

            DB::commit();

            $this->info('Data imported successfully.');
        } catch (\Exception $e) {
            DB::rollback();

            $this->error("Error importing data: {$e->getMessage()}");
        }
    }
}
