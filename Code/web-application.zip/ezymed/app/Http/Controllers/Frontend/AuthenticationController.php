<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\LoginRequest;
use App\Models\Admission;
use App\Models\LabEvents;
use App\Models\LabItem;
use App\Models\MicroBiologyEvents;
use App\Models\Patient;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;

class AuthenticationController extends Controller
{
    public function signInPage(){

        return view('frontend.auth.sign-in');
    }
    public function signInRequest(LoginRequest $request){

        $request->authenticate();

        $request->session()->regenerate();

        return response()->json(['status' => true, 'message' => 'Auth Successfull', 200]);
    }
    public function logout(Request $request)
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('auth.sign-in');
    }
    public function admissionsPage(){
        $data = Admission::leftJoin('patients','admissions.subject_id','patients.subject_id')
        ->get()->toArray();
        return view('dashboard.admissions')->with('records',$data);
    }

    public function getReport(Request $request){

        $subject_id = $request['subject_id'];
        $hadm_id = $request['hadm_id'];
        $labData = LabEvents::where('subject_id',$subject_id)->where('hadm_id',$hadm_id)->limit(5)->get();
        $microData = MicroBiologyEvents::where('subject_id',$subject_id)->where('hadm_id',$hadm_id)->limit(5)->get();
        $labItem = [];
        foreach($labData as $eachLabRecord){
                $labItemData = LabItem::where('itemid',$eachLabRecord['itemid'])->first()->toArray();
                array_push($labItem,$labItemData);
        }
        $admissionRecord = Admission::where('subject_id',$subject_id)->where('hadm_id',$hadm_id)->first();
        $patientPersonalData = Patient::where('subject_id',$subject_id)->first();
        $admissionRecord->patientPersonalData = $patientPersonalData;
        $admissionRecord->Labevents = $labData;
        $admissionRecord->Lab_Items = $labItem;
        $admissionRecord->Microbiology = $microData;
        $finalData = [
            "id"   => "Primary",
            "type" => "json",
            "jsonData" => [ "patient" => $admissionRecord]
        ];
        $passData = json_encode($finalData);

        // dd($passData);
        // API call to Arria studio
        // $response = Http::withHeaders([
        //     'Content-Type' => 'application/json;charset=UTF-8',
        //     'Authorization' => 'bearer eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiJYZWw3azNtczl2NEpkT3dIQlM3SlI0SEciLCJpYXQiOjE2Nzc5NTI2ODMsImV4cCI6MTgzNTYzMjY4MywiaXNzIjoiQUxpdGUiLCJzdWIiOiJHeTRHSkcwZUd2T2IiLCJBTGl0ZS5wZXJtIjpbInByczp4OngweWt5bmowd216Il0sIkFMaXRlLnR0IjoidV9hIn0.mga0_slsUOJa9ah-R1kkO1kJyQ1dPmuXXrLRqKjgBv5I-5ICbq0moo7yl5mSiibjrGbslQ3VlcLLiFWme5Olsw'
        // ])->post('https://app.studio.arria.com:443/alite_content_generation_webapp/text/x0ykynj0wmz', [
        //     "id"   => "Primary",
        //     "type" => "json",
        //     "jsonData" => [ "patient" => $admissionRecord]
        // ]);
        // dd($response);



        return response()->json(['status' => true, 'message' => 'Auth Successfull','data'=> "<p><p>Patient ID: 42066 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Date of Birth: 13-Jun-2061</p><p>Hospital ID: 171628 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Gender: M</p><p>The patient was admitted to the hospital on 2112-02-04 14:49:00.000000 UTC. Upon Admission, it is noted that the patient is single and has a Private insurance coverage.</p>A total of 5 general tests have been prescribed to the patient,1.Anion Gap - 6mEq/L : <strong>abnormal</strong> 2.Glucose - 111mg/dL : <strong>abnormal</strong> 3.Albumin - 2.2g/dL : <strong>abnormal</strong> 4.Calcium,Total - 7.4mg/dL : <strong>abnormal</strong> 5.Calcium,Total - 7.4mg/dL : <strong>abnormal</strong>.From these tests, the patient has been diagnosed with <strong>Tracheal Stenosis</strong>.&nbsp;<p><br></p><p><br></p><p style=\"text-align: left;\">Tracheal stenosis is a condition characterized by the narrowing of the trachea. This narrowing can occur in different parts of the trachea and can range from mild to severe. Tracheal stenosis can be caused by a variety of factors like *Trauma to the trachea*Inflammation or scarring of the trachea*Tumors or abnormal growths in or near the trachea*Treatment options for tracheal stenosis depend on the severity and location of the narrowing. Mild cases may be treated with medications to reduce inflammation or with breathing exercises to improve lung function. More severe cases may require surgery to widen the trachea or to remove tumors or other obstructions.&nbsp;</p><p style=\"text-align: left;\">The patient was also recommended some microbiological test, where the results identified Pseudomonas Aeruginosa,Pseudomonas Aeruginosa, Pseudomonas Aeruginosa, Pseudomonas Aeruginosa and Staph Aureus Coag +.Also the antibodies for the bacteria, Ciprofloxacin,Cefepime,Meropenem,Piperacillin/tazo and Tetracycline were also mentioned for easier diagnosis and treatment.</p>", 200]);


    }
}
