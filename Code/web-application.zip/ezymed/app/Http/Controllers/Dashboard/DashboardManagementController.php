<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardManagementController extends Controller
{
    public function dashboardHome(){
        return view('dashboard.home');
    }
}
