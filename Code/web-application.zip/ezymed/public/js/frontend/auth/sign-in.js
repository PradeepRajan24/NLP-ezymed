"use strict";
var KTSigninGeneral = function() {
    var t, e, i;
    return {
        init: function() {
            t = document.querySelector("#kt_sign_in_form"), e = document.querySelector("#kt_sign_in_submit"), i = FormValidation.formValidation(t, {
                fields: {
                    email: {
                        validators: {
                            notEmpty: {
                                message: "Email address is required"
                            },
                            emailAddress: {
                                message: "The value is not a valid email address"
                            }
                        }
                    },
                    password: {
                        validators: {
                            notEmpty: {
                                message: "The password is required"
                            }
                        }
                    }
                },
                plugins: {
                    trigger: new FormValidation.plugins.Trigger,
                    bootstrap: new FormValidation.plugins.Bootstrap5({
                        rowSelector: ".fv-row"
                    })
                }
            }), e.addEventListener("click", (function(n) {
                n.preventDefault(), i.validate().then((function(i) {
                    if("Valid" == i ){

                        
                        var form_data = new FormData($('#kt_sign_in_form')[0]);
                    
                        $.ajax({
                            type: "POST",
                            url: signInRequestPath,
                            dataType: 'JSON',
                            data: form_data,
                            cache: false,
                            contentType: false,
                            processData: false,
                            async: true,
                            headers: {
                        "cache-control": "no-cache"
                            },
                            beforeSend: function () {
                                e.setAttribute("data-kt-indicator", "on");
                                e.disabled = !0;
                            },
                            success: function (result) {
                                e.removeAttribute("data-kt-indicator");
                                e.disabled = !1
                                if (result.status) {
                                    Swal.fire({
                                        text: "You have successfully logged in!",
                                        icon: "success",
                                        buttonsStyling: !1,
                                        confirmButtonText: "Ok, got it!",
                                        timer: 3000,
                                        customClass: {
                                            confirmButton: "btn btn-primary"
                                        }
                                    }).then((function(e) {
                                        window.location.href =redirectionPath;
                                    }))
                                } else {
                                    Swal.fire({
                                        text: "Sorry, looks like there are some errors detected, please try again.",
                                        icon: "error",
                                        buttonsStyling: !1,
                                        confirmButtonText: "Ok, got it!",
                                        timer: 5000,
                                        customClass: {
                                            confirmButton: "btn btn-primary"
                                        }
                                    }).then((function(e) {
                                        location.reload();
                                    }))
                                }
                            },
            
                            error: function (response) {
                                var errorTXT;
                                    errorTXT = response.responseJSON.errors.email[0];
                                e.removeAttribute("data-kt-indicator");
                                e.disabled = !1
                                Swal.fire({
                                    text: errorTXT,
                                    icon: "error",
                                    buttonsStyling: !1,
                                    confirmButtonText: "Ok, got it!",
                                    timer: 5000,
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                }).then((function(e) {
                                    location.reload();
                                }))
                            }
                        })

                    }
                    else{
                        Swal.fire({
                            text: "Sorry, looks like there are some errors detected, please try again.",
                            icon: "error",
                            buttonsStyling: !1,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        })

                    }
                }))
            }))
        }
    }
}();
KTUtil.onDOMContentLoaded((function() {
    KTSigninGeneral.init()
}));