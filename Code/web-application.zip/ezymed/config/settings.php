<?php

return [

    'userTypes' =>[
        'Developer' => 1,
        'Parish Priest' => 2,
        'Parish Office Staff' => 3,
        'BCC Unit Coordinator' => 4,
        'Youth Represenative' => 5,
    ],
];
   

