        <script>var hostUrl = "#";</script>
		<!--begin::Javascript-->
		<!--begin::Global Javascript Bundle(used by all pages)-->
		<script src="<?php echo e(asset('plugins/global/plugins.bundle.js')); ?>"></script>
		<script src="<?php echo e(asset('js/scripts.bundle.js')); ?>"></script>
		<!--end::Global Javascript Bundle-->
		<!--begin::Page Vendors Javascript(used by this page)-->
		<script src="<?php echo e(asset('plugins/custom/fullcalendar/fullcalendar.bundle.js')); ?>"></script>
		<!--end::Page Vendors Javascript-->
		<!--begin::Page Custom Javascript(used by this page)-->
		<script src="<?php echo e(asset('js/custom/widgets.js')); ?>"></script>
		<script src="<?php echo e(asset('js/custom/apps/chat/chat.js')); ?>"></script>
		<script src="<?php echo e(asset('js/custom/modals/create-app.js')); ?>"></script>
		<script src="<?php echo e(asset('js/custom/modals/upgrade-plan.js')); ?>"></script>
		<script src="<?php echo e(asset('js/custom/intro.js')); ?>"></script>
		<!--end::Page Custom Javascript-->
		<!--end::Javascript--><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ezymed/resources/views/dashboard/layouts/js_footer.blade.php ENDPATH**/ ?>