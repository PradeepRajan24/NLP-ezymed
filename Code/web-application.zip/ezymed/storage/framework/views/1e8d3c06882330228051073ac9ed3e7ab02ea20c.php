<?php $__env->startSection('pageTitle','Admissions'); ?>
<?php $__env->startPush('css'); ?>
<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.3/css/jquery.dataTables.min.css">


<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
<!--begin::Wrapper-->
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<div class="modal fade" id="report_model" tabindex="-1" aria-hidden="true">
			<!--begin::Modal dialog-->
			<div class="modal-dialog modal-xl">
				<!--begin::Modal content-->
				<div class="modal-content rounded">
					<!--begin::Modal header-->
					<div class="modal-header justify-content-end border-0 pb-0">
						<!--begin::Close-->
						<div class="btn btn-sm btn-icon btn-active-color-primary" data-bs-dismiss="modal">
							<!--begin::Svg Icon | path: icons/duotune/arrows/arr061.svg-->
							<span class="svg-icon svg-icon-1">
								<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
									<rect opacity="0.5" x="6" y="17.3137" width="16" height="2" rx="1" transform="rotate(-45 6 17.3137)" fill="black" />
									<rect x="7.41422" y="6" width="16" height="2" rx="1" transform="rotate(45 7.41422 6)" fill="black" />
								</svg>
							</span>
							<!--end::Svg Icon-->
						</div>
						<!--end::Close-->
					</div>
					<!--end::Modal header-->
					<!--begin::Modal body-->
					<div class="modal-body pt-0 pb-15 px-5 px-xl-20">
						<!--begin::Heading-->
						<div class="mb-13 text-center">
							<h1 class="mb-3">Medical Report</h1>
							<div class="text-muted fw-bold fs-5">
							<a href="#" class="link-primary fw-bolder">Laboratory Report & Microbiology Report</a>.</div>
						</div>
						<!--end::Heading-->
						<!--begin::Plans-->
						<div class="d-flex flex-column">
							<!--begin::Row-->
							<div class="row mt-10">
								<!--begin::Col-->
								<div class="col-lg-12">
									<!--begin::Tab content-->
									<div class="tab-content rounded h-100 bg-light p-10">
										<!--begin::Tab Pane-->
										<div class="tab-pane fade show active" id="kt_upgrade_plan_startup">
											<!--begin::Heading-->
											<div class="pb-5">
												<h2 class="fw-bolder text-dark">Transcript</h2>
												<div class="text-muted fw-bold" id="putContentHere">
													
												<p><p>Patient ID: 42066 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; Date of Birth: 13-Jun-2061</p><p>Hospital ID: 171628 &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Gender: M</p><p>The patient was admitted to the hospital on 2112-02-04 14:49:00.000000 UTC. Upon Admission, it is noted that the patient is single and has a Private insurance coverage.</p>A total of 5 general tests have been prescribed to the patient,1.Anion Gap - 6mEq/L : <strong>abnormal</strong> 2.Glucose - 111mg/dL : <strong>abnormal</strong> 3.Albumin - 2.2g/dL : <strong>abnormal</strong> 4.Calcium,Total - 7.4mg/dL : <strong>abnormal</strong> 5.Calcium,Total - 7.4mg/dL : <strong>abnormal</strong>.From these tests, the patient has been diagnosed with <strong>Tracheal Stenosis</strong>.&nbsp;<p><br></p><p><br></p><p style=\"text-align: left;\">Tracheal stenosis is a condition characterized by the narrowing of the trachea. This narrowing can occur in different parts of the trachea and can range from mild to severe. Tracheal stenosis can be caused by a variety of factors like *Trauma to the trachea*Inflammation or scarring of the trachea*Tumors or abnormal growths in or near the trachea*Treatment options for tracheal stenosis depend on the severity and location of the narrowing. Mild cases may be treated with medications to reduce inflammation or with breathing exercises to improve lung function. More severe cases may require surgery to widen the trachea or to remove tumors or other obstructions.&nbsp;</p><p style=\"text-align: left;\">The patient was also recommended some microbiological test, where the results identified Pseudomonas Aeruginosa,Pseudomonas Aeruginosa, Pseudomonas Aeruginosa, Pseudomonas Aeruginosa and Staph Aureus Coag +.Also the antibodies for the bacteria, Ciprofloxacin,Cefepime,Meropenem,Piperacillin/tazo and Tetracycline were also mentioned for easier diagnosis and treatment.</p>

												</div>
											</div>
											<!--end::Heading-->
										</div>
										<!--end::Tab Pane-->
									</div>
									<!--end::Tab content-->
								</div>
								<!--end::Col-->
							</div>
							<!--end::Row-->
						</div>
						<!--end::Plans-->
						<!--begin::Actions-->
						<div class="d-flex flex-center flex-row-fluid pt-12">
							<button type="reset" class="btn btn-primary" data-bs-dismiss="modal">Close</button>
						</div>
						<!--end::Actions-->
					</div>
					<!--end::Modal body-->
				</div>
				<!--end::Modal content-->
			</div>
			<!--end::Modal dialog-->
		</div>
<div class="wrapper d-flex flex-column flex-row-fluid" id="kt_wrapper">
	<?php echo $__env->make('dashboard.layouts.top_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!--begin::Content-->
	<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
		<!--begin::Container-->
		<div class="container-xxl" id="kt_content_container">
				<!--begin::Row-->
				<div class="row gy-5 g-xl-8">
							
								<!--begin::Col-->
								<div class="col-xxl-12">
									<!--begin::Tables Widget 9-->
									<div class="card card-xxl-stretch mb-5 mb-xl-8">
										<!--begin::Header-->
										<div class="card-header border-0 pt-5">
											<h3 class="card-title align-items-start flex-column">
												<span class="card-label fw-bolder fs-3 mb-1">Admissions</span>
												<span class="text-muted mt-1 fw-bold fs-7">Over 5000 admissions</span>
											</h3>
											<div class="card-toolbar" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-trigger="hover" title="Click to add a new Admission">
												<a href="#" class="btn btn-sm btn-light btn-active-primary" data-bs-toggle="modal" data-bs-target="#kt_modal_invite_friends">
												<!--begin::Svg Icon | path: icons/duotune/arrows/arr075.svg-->
												<span class="svg-icon svg-icon-3">
													<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
														<rect opacity="0.5" x="11.364" y="20.364" width="16" height="2" rx="1" transform="rotate(-90 11.364 20.364)" fill="black" />
														<rect x="4.36396" y="11.364" width="16" height="2" rx="1" fill="black" />
													</svg>
												</span>
												<!--end::Svg Icon--> Create New Admission</a>
											</div>
										</div>
										<!--end::Header-->
										<!--begin::Body-->
										<div class="card-body py-3">
											<!--begin::Table container-->
											<div class="table-responsive">
												<!--begin::Table-->
												<table class="table table-row-dashed table-row-gray-300 align-middle gs-0 gy-4">
													<!--begin::Table head-->
													<thead>
														<tr class="fw-bolder text-muted">
															<th class="w-25px">
																<div class="form-check form-check-sm form-check-custom form-check-solid">
																	<input class="form-check-input" type="checkbox" value="1" data-kt-check="true" data-kt-check-target=".widget-9-check" />
																</div>
															</th>
															<th class="min-w-150px">Subject ID</th>
															<th class="min-w-140px">Hadm ID</th>
															<th class="min-w-120px">Admission Type</th>
															<th class="min-w-120px">Admission Location</th>
															<th class="min-w-100px text-end">Actions</th>
														</tr>
													</thead>
													<!--end::Table head-->
													<!--begin::Table body-->
													<tbody>
														<?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														
														<tr>
															<td>
																<div class="form-check form-check-sm form-check-custom form-check-solid">
																	<input class="form-check-input widget-9-check" type="checkbox" value="1" />
																</div>
															</td>
															<td>
																<div class="d-flex align-items-center">
																	<div class="symbol symbol-45px me-5">
																		<img src="<?php echo e(asset('media/avatars/150-11.jpg')); ?>" alt="" />
																	</div>
																	<div class="d-flex justify-content-start flex-column">
																		<a href="#" class="text-dark fw-bolder text-hover-primary fs-6"><?php echo e($record['subject_id']); ?></a>
																		<span class="text-muted fw-bold text-muted d-block fs-7"><?php echo e($record['admittime']); ?></span>
																	</div>
																</div>
															</td>
															<td>
																<a href="#" class="text-dark fw-bolder text-hover-primary d-block fs-6"><?php echo e($record['hadm_id']); ?></a>
																<span class="text-muted fw-bold text-muted d-block fs-7"><?php echo e($record['diagnosis']); ?></span>
															</td>
															<td>
																<a href="#" class="text-dark fw-bolder text-hover-primary d-block fs-6"><?php echo e($record['admission_type']); ?></a>
															</td>
															<td>
																<a href="#" class="text-dark fw-bolder text-hover-primary d-block fs-6"><?php echo e($record['admission_location']); ?></a>
															</td>
															
															<td>
																<div class="d-flex justify-content-end flex-shrink-0">
																<a href="javascript:void(0)" class="btn btn-bg-light btn-color-primary view-report-btn" data-sub-id="<?php echo e($record['subject_id']); ?>" data-hadm-id="<?php echo e($record['hadm_id']); ?>">View Report</a>

																	
																</div>
															</td>
														</tr>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													
													</tbody>
													<!--end::Table body-->
												</table>
												<!--end::Table-->
											</div>
											<!--end::Table container-->
										</div>
										<!--begin::Body-->
									</div>
									<!--end::Tables Widget 9-->
								</div>
								<!--end::Col-->
							</div>
							<!--end::Row-->


		</div>
		<!--end::Container-->
	</div>
	<!--end::Content-->
	<?php echo $__env->make('dashboard.layouts.dash_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!--end::Wrapper-->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
   <script>
	$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
$( document ).ready(function() {
	$("div #putContentHere").empty();

	$('#report_model').on('hidden.bs.modal', function () {
		$("div #putContentHere").empty();
})

	$( ".view-report-btn" ).click(function() {
  
		var subject_id = $(this).attr("data-sub-id");
		var hadm_id = $(this).attr("data-hadm-id");

		url = window.location+'/get-report';
        $.ajax({
				type: "POST",
				url: url,
				data: {
					subject_id:subject_id,
					hadm_id: hadm_id
				},
				success: function (response){
					console.log("Scuccess...!");
					console.log(response);
					$( "div #putContentHere" ).append(response.data);
					$('#report_model').modal('toggle');

				},
				error: function (reponse){
					Swal.fire({
                                    text: "Something went wrong, Please try later !",
                                    icon: "error",
                                    buttonsStyling: !1,
                                    confirmButtonText: "Ok, got it!",
                                    // timer: 7000,
                                    customClass: {
                                        confirmButton: "btn btn-primary"
                                    }
                                }).then((function(e) {
                                    location.reload();
                                }))
				},
				});
});

});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layouts.dash_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/ezymed/resources/views/dashboard/admissions.blade.php ENDPATH**/ ?>