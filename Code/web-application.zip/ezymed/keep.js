"use strict";
var KTSigninGeneral = function() {
    var t, e, i;
    return {
        init: function() {
            t = document.querySelector("#kt_sign_in_form"), e = document.querySelector("#kt_sign_in_submit"), i = FormValidation.formValidation(t, {
                fields: {
                    email: {
                        validators: {
                            notEmpty: {
                                message: "Email address is required"
                            },
                            emailAddress: {
                                message: "The value is not a valid email address"
                            }
                        }
                    },
                    password: {
                        validators: {
                            notEmpty: {
                                message: "The password is required"
                            },
                        }
                    }
                },
                plugins: {
                    trigger: new FormValidation.plugins.Trigger,
                    bootstrap: new FormValidation.plugins.Bootstrap5({
                        rowSelector: ".fv-row"
                    })
                }
            }), e.addEventListener("click", (function(n) {
                n.preventDefault();
                i.validate();
                i.on('core.form.valid', function(event) {

                    var form_data = new FormData($('#kt_sign_in_form')[0]);
                    
                    $.ajax({
                        type: "POST",
                        url: signInRequestPath,
                        dataType: 'JSON',
                        data: form_data,
                        cache: false,
                        contentType: false,
                        processData: false,
                        async: true,
                        headers: {
                      "cache-control": "no-cache"
                        },
                        beforeSend: function () {
                            e.setAttribute("data-kt-indicator", "on");
                            // $(".error").html('');
                            // $('.loader').removeClass('d-none');
                        },
                        success: function (result) {
                            e.removeAttribute("data-kt-indicator");
                            // if (result.status) {
                            //     $('.loader').addClass('d-none');
                            //     swal.fire({
                            //         icon: 'success',
                            //         title: 'Authentication Successful',
                            //         text: 'Logging in securely !',
                            //         timer: 3000,
                            //         showConfirmButton: false,
                            //         onClose: adminDash
                            //     });
                            //     function adminDash() {
                            //         window.location.href = url + "/admin/dashboard";
                            //     };
                            // } else {
                            //     if ($.isPlainObject(result.message)) {
                            //         if (result.message) {
                            //             $('.loader').addClass('d-none');
                            //             $.each(result.message, function(key, value) {
                            //                 if (value[0])
                            //                     $(".error_" + key).html(value[0]);
                            //             });
                            //         }
                            //     } 
                            //     else {
                            //         $('.loader').addClass('d-none');
                            //         swal.fire({
                            //             icon: 'error',
                            //             title: result.message,
                            //             text: result.info,
                            //             confirmButtonText: "ok",
                            //         })
                            //     }
                            // }
                        },
        
                        error: function (response) {
                            e.removeAttribute("data-kt-indicator");
                            // $('.loader').addClass('d-none');
                            // Swal.fire({
                            //     icon: 'error',
                            //     title: 'Oops...',
                            //     text: 'Something Went Wrong Please Try again Later !',
                            //     confirmButtonText: 'OK',
                            // })
                        }
                    })
              });
            }));

        }
    }
}();
        
        KTUtil.onDOMContentLoaded((function() {
            KTSigninGeneral.init()
        }));


        // n.preventDefault(), i.validate().then((function(i) {
        //     "Valid" == i ? (e.setAttribute("data-kt-indicator", "on"), e.disabled = !0, setTimeout((function() {
        //         e.removeAttribute("data-kt-indicator"), e.disabled = !1, Swal.fire({
        //             text: "You have successfully logged in!",
        //             icon: "success",
        //             buttonsStyling: !1,
        //             confirmButtonText: "Ok, got it!",
        //             customClass: {
        //                 confirmButton: "btn btn-primary"
        //             }
        //         }).then((function(e) {
        //             e.isConfirmed && (t.querySelector('[name="email"]').value = "", t.querySelector('[name="password"]').value = "")
        //         }))
        //     }), 2e3)) : Swal.fire({
        //         text: "Sorry, looks like there are some errors detected, please try again.",
        //         icon: "error",
        //         buttonsStyling: !1,
        //         confirmButtonText: "Ok, got it!",
        //         customClass: {
        //             confirmButton: "btn btn-primary"
        //         }
        //     })
        // }))












        // Swal.fire({
        //     text: "You have successfully logged in!",
        //     icon: "success",
        //     buttonsStyling: !1,
        //     confirmButtonText: "Ok, got it!",
        //     customClass: {
        //         confirmButton: "btn btn-primary"
        //     }
        //     }).then(function(e) {
        //         e.isConfirmed && (t.querySelector('[name="email"]').value = "", t.querySelector('[name="password"]').value = "")
        //     });








        "use strict";
var KTSigninGeneral = function() {
    var t, e, i;
    return {
        init: function() {
            t = document.querySelector("#kt_sign_in_form"), e = document.querySelector("#kt_sign_in_submit"), i = FormValidation.formValidation(t, {
                fields: {
                    email: {
                        validators: {
                            notEmpty: {
                                message: "Email address is required"
                            },
                            emailAddress: {
                                message: "The value is not a valid email address"
                            }
                        }
                    },
                    password: {
                        validators: {
                            notEmpty: {
                                message: "The password is required"
                            }
                        }
                    }
                },
                plugins: {
                    trigger: new FormValidation.plugins.Trigger,
                    bootstrap: new FormValidation.plugins.Bootstrap5({
                        rowSelector: ".fv-row"
                    })
                }
            }), e.addEventListener("click", (function(n) {
                n.preventDefault(), i.validate().then((function(i) {
                    if("Valid" == i ){
                        e.setAttribute("data-kt-indicator", "on"), e.disabled = !0, setTimeout((function() {
                            e.removeAttribute("data-kt-indicator"), e.disabled = !1, Swal.fire({
                                text: "You have successfully logged in!",
                                icon: "success",
                                buttonsStyling: !1,
                                confirmButtonText: "Ok, got it!",
                                customClass: {
                                    confirmButton: "btn btn-primary"
                                }
                            }).then((function(e) {
                                e.isConfirmed && (t.querySelector('[name="email"]').value = "", t.querySelector('[name="password"]').value = "")
                            }))
                        }), 2e3)

                    }
                    else{
                        Swal.fire({
                            text: "Sorry, looks like there are some errors detected, please try again.",
                            icon: "error",
                            buttonsStyling: !1,
                            confirmButtonText: "Ok, got it!",
                            customClass: {
                                confirmButton: "btn btn-primary"
                            }
                        })

                    }
                }))
            }))
        }
    }
}();
KTUtil.onDOMContentLoaded((function() {
    KTSigninGeneral.init()
}));




