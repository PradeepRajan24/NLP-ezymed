<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class UserTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::statement ('SET FOREIGN_KEY_CHECKS=0;');
        DB::table ('user_types')->truncate();

        DB::statement ('SET FOREIGN_KEY_CHECKS=1;');
        $data = array(
            array('id' => config('settings.userTypes.Developer'),'user_type_name'=>'Developer') ,
            // array('id' => config('settings.userTypes.Parish Priest'),'user_type_name'=>'Parish Priest') ,
            // array('id' => config('settings.userTypes.Parish Office Staff'),'user_type_name'=>'Parish Office Staff') ,
            // array('id' => config('settings.userTypes.BCC Unit Coordinator'),'user_type_name'=>'BCC Unit Coordinator') ,
            // array('id' => config('settings.userTypes.Youth Represenative'),'user_type_name'=>'Youth Represenative') ,
            
        );
        DB::table ('user_types')->insert ($data);
    }
}
