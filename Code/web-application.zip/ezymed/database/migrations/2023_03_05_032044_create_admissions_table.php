<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdmissionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('admissions', function (Blueprint $table) {
            $table->id('row_id');
            $table->bigInteger('subject_id')->nullable();
            $table->bigInteger('hadm_id')->nullable();
            $table->dateTime('admittime')->nullable();
            $table->dateTime('dischtime')->nullable();
            $table->dateTime('deathtime')->nullable();
            $table->string('admission_type')->nullable();
            $table->string('admission_location')->nullable();
            $table->string('discharge_location')->nullable();
            $table->string('insurance')->nullable();
            $table->string('language')->nullable();
            $table->string('religion')->nullable();
            $table->string('marital_status')->nullable();
            $table->string('ethnicity')->nullable();
            $table->dateTime('edregtime')->nullable();
            $table->dateTime('edouttime')->nullable();
            $table->string('diagnosis')->nullable();
            $table->bigInteger('hospital_expire_flag')->nullable();
            $table->bigInteger('has_chartevents_data')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admissions');
    }
}
