<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePatientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->id('row_id');
            $table->bigInteger('subject_id')->nullable();
            $table->string('gender')->nullable();
            $table->dateTime('dob')->nullable();
            $table->dateTime('dod')->nullable();
            $table->dateTime('dod_hosp')->nullable();
            $table->dateTime('dod_ssn')->nullable();
            $table->bigInteger('expire_flag')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients');
    }
}
