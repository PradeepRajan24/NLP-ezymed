<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLabItemsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lab_items', function (Blueprint $table) {
            $table->id('row_id');
            $table->bigInteger('itemid')->nullable();
            $table->string('label')->nullable();
            $table->string('fluid')->nullable();
            $table->string('category')->nullable();
            $table->string('loinc_code')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lab_items');
    }
}
