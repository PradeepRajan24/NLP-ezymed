<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateLabEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('lab_events', function (Blueprint $table) {
            $table->id('row_id');
            $table->bigInteger('subject_id')->nullable();
            $table->bigInteger('hadm_id')->nullable();
            $table->bigInteger('itemid')->nullable();
            $table->dateTime('charttime')->nullable();
            $table->string('value')->nullable();
            $table->double('valuenum', 8, 2)->nullable();
            $table->string('valueuom')->nullable();
            $table->string('flag')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lab_events');
    }
}
