<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMicroBiologyEventsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('micro_biology_events', function (Blueprint $table) {
            $table->id('row_id');
            $table->bigInteger('subject_id')->nullable();
            $table->bigInteger('hadm_id')->nullable();
            $table->dateTime('chartdate')->nullable();
            $table->dateTime('charttime')->nullable();
            $table->bigInteger('spec_itemid')->nullable();
            $table->string('spec_type_desc')->nullable();
            $table->bigInteger('org_itemid')->nullable();
            $table->string('org_name')->nullable();
            $table->bigInteger('isolate_num')->nullable();
            $table->bigInteger('ab_itemid')->nullable();
            $table->string('ab_name')->nullable();
            $table->string('dilution_text')->nullable();
            $table->string('dilution_comparison')->nullable();
            $table->string('dilution_value')->nullable();
            $table->string('interpretation')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('micro_biology_events');
    }
}
