<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRefTablesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ref_tables', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('lab_item_id')->nullable();
            $table->double('low_limit', 8, 2)->nullable();
            $table->double('high_limit', 8, 2)->nullable();
            $table->string('gender')->nullable();
            $table->string('unit')->nullable();

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ref_tables');
    }
}
