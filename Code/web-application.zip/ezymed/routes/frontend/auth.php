<?php

use App\Http\Controllers\Frontend\AuthenticationController;
use Illuminate\Support\Facades\Route;

Route::prefix('auth')->name('auth.')->middleware(['guest'])->group(function () {
    Route::get('/sign-in',  [AuthenticationController::class, 'signInPage'])->name('sign-in');
    Route::post('/sign-in-request',  [AuthenticationController::class, 'signInRequest'])->name('sign-in-request');
});