<?php

use App\Http\Controllers\Dashboard\DashboardManagementController;
use App\Http\Controllers\Frontend\AuthenticationController;
use Illuminate\Support\Facades\Route;

Route::prefix('dashboard')->middleware(['auth'])->group(function () {
    Route::get('/',  [DashboardManagementController::class, 'dashboardHome'])->name('home');
    Route::post('/logout',  [AuthenticationController::class, 'logout'])->name('logout');
});