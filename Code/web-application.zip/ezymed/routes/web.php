<?php

use App\Http\Controllers\Frontend\AuthenticationController;
use Illuminate\Support\Facades\Route;



// Route::get('/dashboard', function () { return view('dashboard'); })->middleware(['auth'])->name('dashboard');

require __DIR__.'/auth.php';

Route::name('frontend.')->group(function () {
    require __DIR__ . '/frontend/auth.php';
});
Route::name('dashboard.')->group(function () {
    require __DIR__ . '/dashboard/routes.php';
});
Route::get('/',  [AuthenticationController::class, 'signInPage'])->name('sign-in');
Route::get('/admissions',  [AuthenticationController::class, 'admissionsPage'])->name('admissions-page');
Route::post('/admissions/get-report',  [AuthenticationController::class, 'getReport'])->name('get-report');